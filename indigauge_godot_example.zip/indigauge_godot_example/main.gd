extends Node

@onready var status_label: Label = $CanvasLayer/UI/Center/VBox/Status

func _ready() -> void:
    randomize()

    # Configure your key + game identity here:
    # - Set mode to DEV while testing locally
    # - Switch to LIVE + real public key when you want to send data
    IndigaugeClient.mode = IndigaugeTypes.Mode.DEV
    IndigaugeClient.log_level = IndigaugeTypes.LogLevel.INFO

    IndigaugeClient.setup("PUBLIC_KEY_HERE", "Indigauge Example", "0.1.0")
    IndigaugeClient.session_started.connect(func(token: String) -> void:
        status_label.text = "Status: session started (%s)" % token
    )
    IndigaugeClient.session_failed.connect(func(code: int, msg: String) -> void:
        status_label.text = "Status: session failed (%s) %s" % [str(code), msg]
    )
    IndigaugeClient.feedback_sent.connect(func(fid: String) -> void:
        status_label.text = "Status: feedback sent (%s)" % fid
    )

    IndigaugeClient.start_session()
    IndigaugeClient.ig_info("game.start", {"scene":"main"})

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_1:
                IndigaugeClient.ig_info("demo.info", {"n": 1})
                status_label.text = "Status: emitted info event"
            KEY_2:
                IndigaugeClient.ig_warn("demo.warn", {"n": 2})
                status_label.text = "Status: emitted warn event"
            KEY_3:
                IndigaugeClient.ig_error("demo.error", {"n": 3})
                status_label.text = "Status: emitted error event"
