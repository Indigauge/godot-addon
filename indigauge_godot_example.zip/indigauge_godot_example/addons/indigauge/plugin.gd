@tool
extends EditorPlugin

const AUTOLOAD_NAME := "IndigaugeClient"
const AUTOLOAD_PATH := "res://addons/indigauge/client.gd"

const INPUT_ACTION := "indigauge_toggle_feedback"
const DEFAULT_KEY := KEY_F2

func _enter_tree() -> void:
    _ensure_autoload()
    _ensure_input_action()
    print("[Indigauge] Plugin enabled. Autoload added: ", AUTOLOAD_NAME)

func _exit_tree() -> void:
    _remove_input_action()
    _remove_autoload()
    print("[Indigauge] Plugin disabled. Autoload removed: ", AUTOLOAD_NAME)

func _ensure_autoload() -> void:
    if ProjectSettings.has_setting("autoload/%s" % AUTOLOAD_NAME):
        return
    add_autoload_singleton(AUTOLOAD_NAME, AUTOLOAD_PATH)

func _remove_autoload() -> void:
    if not ProjectSettings.has_setting("autoload/%s" % AUTOLOAD_NAME):
        return
    remove_autoload_singleton(AUTOLOAD_NAME)

func _ensure_input_action() -> void:
    if INPUT_ACTION in InputMap.get_actions():
        return

    InputMap.add_action(INPUT_ACTION)

    var ev := InputEventKey.new()
    ev.keycode = DEFAULT_KEY
    InputMap.action_add_event(INPUT_ACTION, ev)

    ProjectSettings.save()

func _remove_input_action() -> void:
    if not (INPUT_ACTION in InputMap.get_actions()):
        return
    InputMap.erase_action(INPUT_ACTION)
    ProjectSettings.save()
