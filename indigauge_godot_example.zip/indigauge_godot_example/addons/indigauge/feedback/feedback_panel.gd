extends Control

@onready var dim: ColorRect = $Dim
@onready var category: OptionButton = $Center/PanelContainer/VBox/Form/CategoryRow/Category
@onready var question: LineEdit = $Center/PanelContainer/VBox/Form/QuestionRow/Question
@onready var message: TextEdit = $Center/PanelContainer/VBox/Form/MessageRow/Message
@onready var screenshot: CheckBox = $Center/PanelContainer/VBox/Form/OptionsRow/Screenshot
@onready var err_label: Label = $Center/PanelContainer/VBox/Footer/Error
@onready var submit: Button = $Center/PanelContainer/VBox/Footer/Buttons/Submit
@onready var cancel: Button = $Center/PanelContainer/VBox/Footer/Buttons/Cancel

func _ready() -> void:
    submit.pressed.connect(_on_submit)
    cancel.pressed.connect(_close)
    dim.gui_input.connect(_on_dim_input)
    message.grab_focus()

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        _close()

func _on_dim_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed:
        _close()

func _on_submit() -> void:
    var cat := category.get_item_text(category.selected)
    var msg := message.text.strip_edges()
    if msg.length() < 2:
        _show_error("Please enter at least 2 characters.")
        return

    # IndigaugeClient is an Autoload singleton when plugin enabled (or in the example project).
    IndigaugeClient.submit_feedback(msg, cat, question.text.strip_edges(), screenshot.button_pressed)
    _close()

func _show_error(s: String) -> void:
    err_label.text = s
    err_label.visible = true

func _close() -> void:
    queue_free()
