class_name IndigaugeCore

static var _dispatcher: Callable = Callable()

static func set_event_dispatcher(d: Callable) -> void:
    _dispatcher = d

static func validate_event_type(s: String) -> Dictionary:
    if s.length() < 3:
        return {"ok": false, "error": "too short"}
    var dot := s.find(".")
    if dot == -1:
        return {"ok": false, "error": "missing '.'"}
    if s.rfind(".") != dot:
        return {"ok": false, "error": "multiple '.'"}
    if dot == 0 or dot == s.length() - 1:
        return {"ok": false, "error": "'.' at edge"}
    for ch in s:
        if ch == ".": continue
        var o := ch.ord()
        var is_letter := (o >= "A".ord() and o <= "Z".ord()) or (o >= "a".ord() and o <= "z".ord())
        if not is_letter:
            return {"ok": false, "error": "non-letter"}
    return {"ok": true}

static func emit(level: String, event_type: String, metadata: Variant = null, ctx: Dictionary = {}) -> bool:
    var v := validate_event_type(event_type)
    if not v.ok:
        return false
    if _dispatcher.is_null():
        return false
    return _dispatcher.call(level, event_type, metadata, ctx)

static func bucket_cores(n: int) -> String:
    if n <= 2: return "1-2"
    if n <= 4: return "3-4"
    if n <= 8: return "6-8"
    return ">8"

static func coarsen_cpu_name(cpu_raw: String) -> String:
    var name := cpu_raw.to_lower()
    if name.find("apple m1") != -1: return "Apple M1"
    if name.find("apple m2") != -1: return "Apple M2"
    if name.find("apple m3") != -1: return "Apple M3"
    if name.find("intel") != -1:
        if name.find("i3") != -1: return "Intel i3"
        if name.find("i5") != -1: return "Intel i5"
        if name.find("i7") != -1: return "Intel i7"
        if name.find("i9") != -1: return "Intel i9"
        return "Intel (Other)"
    if name.find("amd") != -1:
        if name.find("threadripper") != -1: return "AMD Ryzen Threadripper"
        if name.find("ryzen") != -1: return "AMD Ryzen"
        if name.find("epyc") != -1: return "AMD EPYC"
        return "AMD (Other)"
    if name.find("arm") != -1 or name.find("cortex") != -1:
        return "ARM (Generic)"
    return ""
