# Indigauge Godot SDK — Example Project

## Run
1. Open the folder in **Godot 4.x**
2. Ensure the plugin is enabled:
   - Project → Project Settings → Plugins → **Indigauge** → Enable
3. Press **Play**

## What to try
- Press **F2** to open/close the feedback panel.
- Press **1 / 2 / 3** to emit info/warn/error events.

## Configuration
- In `main.gd`, set:
  - `IndigaugeClient.mode = IndigaugeTypes.Mode.DEV` for local testing (no network assumptions)
  - switch to `LIVE` and provide your `PUBLIC_KEY_HERE` to send real data.

## Files
- `addons/indigauge/` contains the SDK addon (plugin + runtime).
- `main.tscn` + `main.gd` is a tiny demo scene using the SDK.
